
enum Direction {
	Horizontal,
	Vertical
}
